After you have installed DVODE_F90 and run the two example programs
in the distribution file, you may wish to run the test program
'stiffoptions.f90' to test your installation. It solves each of the
test problems in the Toronto stiff test suite in several different
ways to test the dense, banded, and sparse Jacobian options using
several different error tolerances. All results are written to a
file named 'stiffoptions.dat.' If after running the program, the
last line of this file does not read as follows: 'No errors occurred.',
please contact one of the authors.
